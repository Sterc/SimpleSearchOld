<?php

namespace Elastica\Exception;

class BulkException extends \RuntimeException implements ExceptionInterface
{
}
