<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c6cbfff488579a93890480380c619aca',
      'native_key' => 'sisea',
      'filename' => 'modNamespace/5380757eed3b4db4b85b36abeeac0420.vehicle',
      'namespace' => 'sisea',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98f0dbd77cf20c146fd1f63741cc571e',
      'native_key' => 'sisea.driver_class',
      'filename' => 'modSystemSetting/43dff6de4d4c51bb29ca1cc91ecac95a.vehicle',
      'namespace' => 'sisea',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '664091a1d9c88d30e8e295110eea7646',
      'native_key' => 'sisea.driver_class_path',
      'filename' => 'modSystemSetting/d7943533628f47be33e2b3b502fcf7d1.vehicle',
      'namespace' => 'sisea',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8aae6c7982dda6f4c32d2485e6bb25aa',
      'native_key' => 'sisea.driver_db_specific',
      'filename' => 'modSystemSetting/f9ebf47f4686dd48a333ee6a01fd40ec.vehicle',
      'namespace' => 'sisea',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '8978a08158be922e7c85e28466c7a91a',
      'native_key' => NULL,
      'filename' => 'modCategory/55158404f9ac1a5781a6020b580f1268.vehicle',
      'namespace' => 'sisea',
    ),
  ),
);